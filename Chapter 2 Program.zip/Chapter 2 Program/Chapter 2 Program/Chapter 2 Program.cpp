#include <iostream>
using namespace std;

// Caleb Jones, CIS 251, Chapter 2 Programming Assignment

int main() {

	double hourlyWage;
	double hoursWorked;
	double grossPay;
	double netPay;
	double taxRate = '27';

	cout << "Google" << endl;
	cout << endl;
	cout << "Wage Calculator" << endl;

	cin >> hourlyWage;
	cin >> hoursWorked;

	cout << "The hourly wage is" << " " << hourlyWage << endl;
	cout << "The hours worked are" << " " << hoursWorked << endl;
	cout << "The tax rate is" << " " << taxRate << endl;

	grossPay = hourlyWage* hoursWorked;

	cout << "Total gross pay is" << " " << grossPay << endl;

	netPay = grossPay / taxRate;

	cout << "The net pay is" << " " << netPay << endl;
}